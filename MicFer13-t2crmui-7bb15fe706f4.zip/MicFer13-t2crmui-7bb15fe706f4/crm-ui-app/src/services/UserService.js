import http from '../http-common';

export class UserService {
    create(data) {
        return http.post("/adduser", data)
    }
}

export default new UserService();