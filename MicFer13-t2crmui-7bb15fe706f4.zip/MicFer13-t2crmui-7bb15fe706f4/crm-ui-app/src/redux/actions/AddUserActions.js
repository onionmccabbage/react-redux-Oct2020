import { ADD_USER_REQUEST, ADD_USER_SUCCESS, ADD_USER_FAIL } from "../constants/UserConstants"
import UserService from "../../services/UserService";

const addUser = (user) =>  (dispatch) => {
    console.log("HELLO")
    try {
        console.log("IN ADD_USER_REQUEST")
        dispatch({ type: ADD_USER_REQUEST });
        UserService.create(user)
            .then(response => {
                console.log("IN ADD_USER_SUCCESS")
                dispatch({ type: ADD_USER_SUCCESS})
            });
    } catch (error) {
        console.log("IN ADD_USER_FAIL: ", error)
        dispatch({ type: ADD_USER_FAIL, payload: error });
    }
};

export default addUser;