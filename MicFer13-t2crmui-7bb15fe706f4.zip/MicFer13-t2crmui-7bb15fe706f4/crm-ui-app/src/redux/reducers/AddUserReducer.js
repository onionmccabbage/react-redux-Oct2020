import {
    ADD_USER_REQUEST,
    ADD_USER_SUCCESS,
    ADD_USER_FAIL
} from "../constants/UserConstants"

const initialState = {
    user: {
        firstname: "",
        surname: "",
        gender: "",
        date_of_birth: "",
        email_address: "",
        address: "",
        zipcode: "",
        phone_number: "",
        method_of_contact: ""
    }
}

function addUserReducer(state = initialState, action) {
    switch (action.type) {
        case 'SET_FIRSTNAME':
            return {...state, user: { firstname: action.value} };
        case 'SET_LASTNAME':
            return {...state, user: { surname: action.value} };
        case 'SET_GENDER':
            return {...state, user: { gender: action.value} };
        case 'SET_DOB':
            return {...state, user: { date_of_birth: action.value} };
        case 'SET_EMAIL_ADDRESS':
            return {...state, user: { email_address: action.value} };
        case 'SET_ADDRESS':
            return {...state, user: { address: action.value} };
        case 'SET_ZIP_CODE':
            return {...state, user: { zipcode: action.value} };
        case 'SET_CONTACT_NUMBER':
            return {...state, user: { phone_number: action.value} };
        case 'SET_PREFERRED_METHOD':
            return {...state, user: { method_of_contact: action.value} };
        case ADD_USER_REQUEST:
            return {...state};
        case ADD_USER_SUCCESS:
            return {...state};
        case ADD_USER_FAIL:
            return {...state, error: action.payload};
        default:
            return state;
    }
}

export default addUserReducer;