import { combineReducers } from 'redux'
import AddUserReducer from "./AddUserReducer";

export default combineReducers({
    AddUserReducer
})