export const getCustomers = state => {
    return state.customerList;
}