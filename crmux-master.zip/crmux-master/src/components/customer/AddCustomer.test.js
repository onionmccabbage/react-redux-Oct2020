describe("The Customer Add component", () => {
    it("renders as expected", () => {

    });

    it("The Add User Button is disabled initially", () => {


    });

    it("The Add User Button is enabled after entering required data", () => {

    });
  });