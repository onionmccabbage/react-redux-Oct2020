import React from "react";

function Home() {
  return (
    <div className="homeMessage">
      <h1>Welcome to the only CRM application you would ever need.</h1>
    </div>
  );
}

export default Home;
