import React from "react";

function HelpScreen() {
  return (
    <div className="homeMessage">
      <h1>This system is so easy, you don't need any help to use it.</h1>
    </div>
  );
}

export default HelpScreen;
